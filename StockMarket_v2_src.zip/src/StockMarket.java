/**
 * Stock Market
 * 
 * Ported to Java by David Arbuthnot
 *
 * Based on the original Basic game of Stock Market available here
 * https://github.com/coding-horror/basic-computer-games/blob/main/83_Stock_Market/stockmarket.bas
 * 
 * Note:  My goal was to create a version of the 1970's game in Java, without adding any
 * new features and staying as true as possible to the original game play including
 * display formatting, etc.
 */



import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class StockMarket {
	
	private final static double START_CASH = 10000.00d;
	private final static double BROKERAGE_FEE = 0.01;
	
    private enum GAME_STATE {
        STARTUP,
        INIT,
        TRADE,
        END_OF_DAY,
        END_GAME,
        GAME_OVER
    }

    // Current game state
    private GAME_STATE gameState;
    
    //Assets and stocks
	private ArrayList<Asset> assets;
	private ArrayList<Stock> stocks;
	
	//Set starting cash value
    private double cash = START_CASH;
    private double bf = BROKERAGE_FEE;
    
    //Game system variables
    private double slope;
    private int daysTrending;
    private int bigChangeUpIndex;
    private int bigChangeUpDays = 0;
    private int bigChangeDownIndex;
    private int bigChangeDownDays = 0;   
    
    //keyboard scanner for user input
    Scanner kbScanner = new Scanner(System.in);
    
    
    public void playStockMarket() {
    	gameState = GAME_STATE.INIT;

        do {
            switch (gameState) {

                case INIT:
                	//Display game title and credits
                	System.out.println("" + generateTabs(30).toString() + "STOCK MARKET");
                	System.out.println(generateTabs(15).toString() + "CREATIVE COMPUTING  MORRISTOWN, NEW JERSEY");
                	System.out.println("\n\n\n");
                	//Display instructions?
                	System.out.print("DO YOU WANT THE INSTRUCTIONS (YES-TYPE 1, NO-TYPE 0)?");
                	int i = getIntegerInput();
                	System.out.println("\n\n");
                	if (i != 0) {
                		System.out.print("THIS PROGRAM PLAYS THE STOCK MARKET.  YOU WILL BE GIVEN\n"
                				+ "$10,000 AND MAY BUY OR SELL STOCKS.  THE STOCK PRICES WILL\n"
                				+ "BE GENERATED RANDOMLY AND THEREFORE THIS MODEL DOES NOT\n"
                				+ "REPRESENT EXACTLY WHAT HAPPENS ON THE EXCHANGE.  A TABLE\n"
                				+ "OF AVAILABLE STOCKS, THEIR PRICES, AND THE NUMBER OF SHARES\n"
                				+ "IN YOUR PORTFOLIO WILL BE PRINTED.  FOLLOWING THIS, THE\n"
                				+ "INITIALS OF EACH STOCK WILL BE PRINTED WITH A QUESTION\n"
                				+ "MARK.  HERE YOU INDICATE A TRANSACTION.  TO BUY A STOCK\n"
                				+ "TYPE +NNN, TO SELL A STOCK TYPE -NNN, WHERE NNN IS THE\n"
                				+ "NUMBER OF SHARES.  A BROKERAGE FEE OF 1% WILL BE CHARGED\n"
                				+ "ON ALL TRANSACTIONS.  NOTE THAT IF A STOCK'S VALUE DROPS\n"
                				+ "TO ZERO IT MAY REBOUND TO A POSITIVE VALUE AGAIN.  YOU\n"
                				+ "HAVE $10,000 TO INVEST.  USE INTEGERS FOR ALL YOUR INPUTS.\n"
                				+ "(NOTE:  TO GET A 'FEEL' FOR THE MARKET RUN FOR AT LEAST\n"
                				+ "10 DAYS)\n");
                		System.out.print("-----GOOD LUCK!-----\n\n\n");
                	}
                	//Set game state to startup
                	gameState = GAME_STATE.STARTUP;
                    break;

                case STARTUP:
                	//Generate initial assets and random variables
                	stocks = initStocks();
                	assets = initAssets();
                	slope = generateSlope();
                	daysTrending = generateDaysTrending();
                	//Generate new randomized stock values based on the start values at init
                	generateNewStockValues();
                	//Display initial stock values
                	displayInitialStocks();
                	
                	displayExchangeAverage(false);
                	//Set game state to trade
                	gameState = GAME_STATE.TRADE;
                    break;

                case TRADE:
                	//Get values for individual asset trades
                	//The enerTrades method also verifies that requested trades don't exceed asset limits
                	do {
                
                	}while (!enterTrades());
                	//Set game state to end of day
                	gameState = GAME_STATE.END_OF_DAY;
                	break;

                case END_OF_DAY:
                	//Decrement daysTrending for current slope
                	daysTrending -= 1;
                	System.out.println("\n\n**********     END OF DAY'S TRADING     **********\n\n");
                	generateNewStockValues();
                	displayAssets();
                	displayExchangeAverage(true);
                	displayAssetSummary();
                	//Continue?
                	boolean playAgain = true;
                	System.out.print("DO YOU WISH TO CONTINUE (YES-TYPE 1, NO-TYPE 0)? ");
                	if ( getIntegerInput() == 0) {
                		playAgain = false;
                	}
                	//Update slope and days trending
                	//Set game state to trade if continue = yes otherwise game state to game over
                	if (playAgain) {
                		if ( daysTrending == 0 ) {
                			daysTrending = generateDaysTrending();
                			slope = generateSlope();
                		}
                		gameState = GAME_STATE.TRADE;
                	}else {
                		gameState = GAME_STATE.END_GAME;
                	}
                    break;
                	
                case END_GAME:
                	System.out.println ("HOPE YOU HAD FUN!!");
                	gameState = GAME_STATE.GAME_OVER;
                	break;
                	
                case GAME_OVER:
                	break;
            }
        } while (gameState != GAME_STATE.GAME_OVER);
    }
    
    
    //Displays current asset summary at end of day
    private void displayAssetSummary() {
    	double stockAssets = 0.0d;
    	double totalAssets = 0.0;
    	
    	for (Asset asset : assets) {
    		stockAssets += asset.getValue();
    	}
    	stockAssets = (int)(100.0d * (stockAssets) + 0.5) / 100.0d;
    	totalAssets = (int)(100.0d * (stockAssets + cash) + 0.5) / 100.0d;
		System.out.println("\nTOTAL STOCK ASSETS ARE   $ " + stockAssets + "\n"
				+ "TOTAL CASH ASSETS ARE    $ " + cash + "\n"
				+ "TOTAL ASSETS ARE         $ " + totalAssets +"\n\n");
	}


    //Used at Startup to display initial stock info to user
	private void displayInitialStocks() {
    	System.out.println("STOCK                       INITIALS      PRICE/SHARE");
    	for (Stock stock : stocks) {
    		System.out.println(stock.getName() + generateTabs(30 - stock.getName().length()) + stock.getShortName() + generateTabs(10) + stock.getCurrentPrice());
    	}
	}
	
    
	//Used to display assets throughout game play
    private void displayAssets() {
    	System.out.println("STOCK         PRICE/SHARE   HOLDINGS      VALUE         NET PRICE CHANGE");
    	for (Asset asset : assets) {
    		System.out.println(asset.getStock().getShortName() + generateTabs(12) 
    		+ asset.getStock().getCurrentPrice() + generateTabs(14 - Double.toString(asset.getStock().getCurrentPrice()).length())
    		+ asset.getQuantity() + generateTabs(16 - Double.toString(asset.getQuantity()).length()) 
    		+ (asset.getValue()) + generateTabs(13 - Double.toString(asset.getValue()).length()) 
    		+ asset.getStock().getPriceChange());
    	}
    }
    

    //Displays exchange averages at startup and end of day.  Bool withChange = true will display the average days change at end of day
    private void displayExchangeAverage(boolean withChange) {
    	double currentAverage = 0.0d;
    	double previousAverage = 0.0d;
    	for (Stock stock : stocks) {
    		currentAverage += stock.getCurrentPrice();
    		previousAverage += stock.getPreviousPrice();
    	}
    	currentAverage /= 5;
    	previousAverage /= 5;
    	currentAverage = (int)(100.0d * currentAverage + 0.5) / 100.0d;
    	previousAverage = (int)(100.0d * previousAverage + 0.5) / 100.0d;
    	double change = (int)(100.0d * (currentAverage - previousAverage) + 0.5) / 100.0d;
    	System.out.println("\n\n");
    	if (!withChange) {
    		System.out.println("NEW YORK STOCK EXCHANGE AVERAGE:  " + currentAverage + "\n");
    	}else {
    		System.out.println("NEW YORK STOCK EXCHANGE AVERAGE:  " + currentAverage + " NET CHANGE  " + change + "\n");
    	}
    }
    
    
    //Present stocks to user and get input for trades (-nn, sell or +nn buy)
	private boolean enterTrades() {
		int i = 0;
		int[] assetChangeQuantity = new int[5];
		double[] assetChangeValue = new double[5];
		double totalAssetChange = 0.0;
		double totalAssetChangeWithFee = 0.0;
		System.out.println("WHAT IS YOUR TRANSACTION IN");
		//Loop through stocks and get user input
		for (Stock stock : stocks) {
			System.out.print(stock.getShortName() + "? ");
			assetChangeQuantity[i] = getIntegerInput();
			i++;
		}
		//Check for over sold stock
		for (i = 0 ; i < 5 ; i++) {
			if (assetChangeQuantity[i] < 0) {
				if (-assetChangeQuantity[i] > assets.get(i).getQuantity()) {
					System.out.println("\nYOU HAVE OVERSOLD A STOCK; TRY AGAIN.");
					return false;
				}
			}	
		}
		//Check for over purchased assets
		for (i = 0 ; i < 5 ; i++) {
			assetChangeValue[i] = (int)(100.0d * (assetChangeQuantity[i] * assets.get(i).getStock().getCurrentPrice()) + 0.5) / 100.0d;
			totalAssetChange += assetChangeValue[i];			
		}
		totalAssetChangeWithFee = (int)(100.0d * ((totalAssetChange * bf) + totalAssetChange) + 0.5) / 100.0d;
		if (totalAssetChangeWithFee > cash) {
			System.out.println ("\nYOU HAVE USED $" + (int)(100.0d * (cash - totalAssetChangeWithFee) + 0.5) / 100.0d + " MORE THAN YOU HAVE.");
			return false;
		}
		//Commit asset changes
		for (i = 0 ; i < 5 ; i++) {
			assets.get(i).setQuantity(assets.get(i).getQuantity() + assetChangeQuantity[i]);
		}
		cash = (int)(100.0d * (cash - totalAssetChangeWithFee) + 0.5) / 100.0d;
		//Return true for all trades valid
		return true;
	}


	//Initialize stock objects with starting values
    private ArrayList<Stock> initStocks(){
    	ArrayList<Stock> stocks = new ArrayList<>();
    	stocks.add(new Stock("INT. BALLISTIC MISSILES","IBM", 100.0d));
    	stocks.add(new Stock("RED CROSS OF AMERICA","RCA", 85.0d));
    	stocks.add(new Stock("LICHTENSTEIN, BUMRAP & JOKE","LBJ", 150.0d));
    	stocks.add(new Stock("AMERICAN BANKRUPT CO.","ABC", 140.0d));
    	stocks.add(new Stock("CENSURED BOOKS STORE","CBS", 110.0d));
    	return stocks;
    }
    
    
    //Initialize stock Asset holdings (cash is kept in the variable cash)
	private ArrayList<Asset> initAssets() {
		ArrayList<Asset> returnAssets = new ArrayList<>();
		for (Stock stock : stocks) {
			returnAssets.add(new Asset(stock, 0));
		}
		return returnAssets;
	}
	
    
	//Set stock trending slope
    private double generateSlope() {
    	double slope = (int)((Math.random()/10) * 100 + .5) / 100.0d;
    	//Set slope direction + or -
    	if (Math.random() > 0.5) {
    		slope *= -1;
    	}
    	return slope;
    }
    
    
    //Generate days trending to determine how long the current slope lasts
    private int generateDaysTrending() {
    	int daysTrending = (int) (4.99 * Math.random() + 1);
    	return daysTrending;
    }
    
    
    private void generateNewStockValues() {
    	//Set big change parameters
    	int bigChange;
    	boolean bigChangeUpFlag = false;
    	boolean bigChangeDownFlag = false;
		
		if (bigChangeUpDays == 0) {
			int[] bigChangeUpParams = generateBigChangeParams();
			bigChangeUpIndex = bigChangeUpParams[0];
			bigChangeUpDays = bigChangeUpParams[1]; 
			bigChangeUpFlag = true;
		}
		
		if (bigChangeDownDays == 0) {
			int[] bigChangeDownParams = generateBigChangeParams();
			bigChangeDownIndex = bigChangeDownParams[0];
			bigChangeDownDays = bigChangeDownParams[1];
			bigChangeDownFlag = true;
		}
    	//Loop through stocks to set changes
    	for (Stock stock : stocks) {
    		bigChange = 0;
    		//Check if stock is set for big change up
    		if (stocks.indexOf(stock) == bigChangeUpIndex && bigChangeUpFlag) {
    			bigChange += 10;
    			bigChangeUpFlag = false;
    		}
    		//Check if stock is set for big change down
    		if (stocks.indexOf(stock) == bigChangeDownIndex && bigChangeDownFlag) {
    			bigChange -= 10;
    			bigChangeDownFlag = false;
    		}
    		
    		double change = Math.random();
    		if (change <= 0.25) {
    			change = 0.25;
    		}else if (change <= 0.50) {
    			change = 0.50;
    		}else if (change <= 0.75) {
    			change = 0.75;
    		}else {
    			change = 0.00;
    		}
    		//Calculate total change for current stock
    		double totalChange = (int)(slope * stock.getCurrentPrice()) + change + (3 - 6*Math.random() + .5) + bigChange;
    		totalChange = (int)(100.0d * totalChange + 0.5) / 100.0d;
    		stock.setPreviousPrice(stock.getCurrentPrice());
    		stock.setCurrentPrice((int)(100.0d * (totalChange + stock.getCurrentPrice()) + 0.5) / 100.0d);
    		stock.setPriceChange(totalChange);
    	}
    	bigChangeUpDays -= 1;
		bigChangeDownDays -= 1;
    }
    
    
    private int[] generateBigChangeParams() {
    	int[] bigChange = new int[2];
    	bigChange[0] = (int) (4.99 * Math.random());
    	bigChange[1] = (int) (4.99 * Math.random() + 1);
    	return bigChange;
    }
    
    
    private String generateTabs(int numSpaces) {
    	char[] spaces = new char[numSpaces];
    	for (int i = 0 ; i < numSpaces; i++) {
    		Arrays.fill(spaces, ' ');;
    	}
    	return new String(spaces);
    }
    
    
    private int getIntegerInput() {
    	int i = 0;
    	boolean validInput = false;
    	do {
    		String kbInput = kbScanner.next();
    		try {
    			i = Integer.parseInt(kbInput);
    			validInput = true;
    		} catch (NumberFormatException e) {
    			System.out.println ("!NUMBER EXPECTED - RETRY INPUT LINE");
    			System.out.print("?");
    		}
    	} while (!validInput);
    	return i;
    }

}
