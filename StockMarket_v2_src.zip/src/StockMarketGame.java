
public class StockMarketGame {

	public static void main(String[] args) {
		
		StockMarket stock = new StockMarket();
		stock.playStockMarket();
		
	}
	

}
